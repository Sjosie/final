from django.db import models
from django.utils import timezone


class Post(models.Model):
    author = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    text = models.TextField()
    created_date = models.DateTimeField(
            default=timezone.now)
    published_date = models.DateTimeField(
            blank=True, null=True)

    def publish(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.title


class Header(models.Model):
    work_schedule = models.TextField()
    # instagramlink = models.TextField()
    # facebooklink = models.TextField()
    # vklink = models.TextField()
    email = models.TextField()
    phone = models.TextField()
    rent = models.TextField()
    # logo_path = models.TextField()
    logo34x46 = models.ImageField()


class Note(models.Model):
    authorr = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    titlee = models.CharField(max_length=200)
    textt = models.TextField()
    created_datee = models.DateTimeField(
            default=timezone.now)
    published_datee = models.DateTimeField(
            blank=True, null=True)

    def publish(self):
        self.published_datee = timezone.now()
        self.save()

    def __str__(self):
        return self.titlee

# class Slider(models.Model):
    