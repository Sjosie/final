## 1.2.3

- Added Polish language.
- Updated jQuery dependency to a latest version and made it as peer.
