<?php 

	$connection = mysqli_connect('127.0.0.1', 'root', '', 'practice_db');

	/*
	
	cv15567_fisher
	w11wHjdE

	if ( $connection == true ) {
		echo 'Подключение к базе данных прошло успешно. <br>';
	} else {
		echo 'Не удалось подключиться к базе данных.';
		exit();
	}*/


?>