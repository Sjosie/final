<?php

  $config = array (
    'work_schedule' => 'Пн - Пт: 09:00 - 19:00',
    'email'         => 'fisher@fisher.com',
    'phone'         => '8 (3952) 000 000',
    'rent'          => 'Бесплатная доставка при покупке от 5000 руб.',
    'logo_path'     => 'img/logo.png',
    'logo_name'     =>  'Бюро путешествий мистера Финча'
  );

?>