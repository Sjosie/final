<?php 

	$connection = mysqli_connect('92.53.96.158', 'cv15567_fisher', 'w11wHjdE', 'cv15567_fisher');

	/*
	
	cv15567_fisher
	w11wHjdE

	if ( $connection == true ) {
		echo 'Подключение к базе данных прошло успешно. <br>';
	} else {
		echo 'Не удалось подключиться к базе данных.';
		exit();
	}*/


?>