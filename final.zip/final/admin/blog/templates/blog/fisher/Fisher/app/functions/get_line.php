<?php

  function get_line($color) {
    ?>

    <div class="line_wrapp">
      <div class="line <?php echo"$color"; ?>"></div>
      <div class="subline <?php echo"$color"; ?>"></div>
    </div>

    <?php
  }

?>