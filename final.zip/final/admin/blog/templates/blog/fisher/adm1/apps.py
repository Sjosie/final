from django.apps import AppConfig


class Adm1Config(AppConfig):
    name = 'adm1'
